import 'package:flutter/cupertino.dart';

TextStyle Text(){
  return TextStyle(
    fontSize: 25,
    fontWeight: FontWeight.bold,
  );
}