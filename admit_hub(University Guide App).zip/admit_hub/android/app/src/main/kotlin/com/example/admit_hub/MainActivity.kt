package com.example.admit_hub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
